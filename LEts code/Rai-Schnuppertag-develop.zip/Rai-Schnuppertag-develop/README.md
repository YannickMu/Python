# Rai-Schnuppertag

Hier sind die gesammten Aufgaben für den Schnuppertag bei Raiffeisen. Die Projekte wurden von [jx4n16](https://github.com/jx4n16) und [franjofranjic](https://github.com/franjofranjic) entwickelt, jedoch habe ich einige Anpassungen vorgenommen. Die Orginal-Projekte sind hier verfügbar:

- [Rai-Schnuppertag](https://github.com/franjofranjic/Rai-Schnuppertag)
- [Rock-Paper-Scissors](https://github.com/jx4n16/Rock-Paper-Scissors)