console.log('Start');

/*
*   Aufgabe 1: Ausgabe
*   -----------------------------------
*   1. Gebe deinen Namen, Alter und Geburtsdatum aus
*   2. Gebe eine Info aus
*   3. Gebe eine Warunung aus
*   4. Gebe einen Fehler aus
*/

/*   Aufgabe 2: Variabeln 1.0
*   -----------------------------------
*   Deklarieren sie Variabeln für ihren Vorname, Nachname, Geburtstag und Alter und geben Sie diese aus
*/


/*   Aufgabe 3: Variabeln 2.0
*   -----------------------------------
*   Deklarieren sie ein Array mit den Namen Ihrer Familienmitgliedern
*   Deklarieren sei ein Boolean ob sie männlich sind oder nicht
*/


/*   Aufgabe 4: Functions 1.0
*   -----------------------------------
*   Erstelle eine Function die den Rest der Division ausgibt.
*/

/*   Aufgabe 5: Functions 2.0
*   -----------------------------------
*   Erstelle eine Function die den Rest einer Division zurück gibt
*/

/*   Aufgabe 6: Rechner 1.0
*   -----------------------------------
*   Erstelle vier Functions (Addition, Subtraktion, Division, Multiplikation)
*   Gebe zwei Zahlen mit und verrechne sie entsprechend der Operation
*/