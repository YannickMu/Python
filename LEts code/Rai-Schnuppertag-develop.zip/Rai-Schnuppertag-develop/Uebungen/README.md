# Rai-Schnuppertag
Schnuppertag Aufgaben 

1. Teil 
Kennenlernen was ist eine Variable was ist eine Function 
Was sind Variabeln wie gebe ich diese aus wie Rechne ich diese zusammen wie manipuliere ich die etc. 
Taschenrechner Functions einfach aufbauen

2. Teil
Was ist eine IF-ELSE Boolschalgebra etc. 
Altersaufgabe und so weitere aufgaben Schwerpunkt setzen

3. Teil
Schleifen For-Schleifen
While-Schleifen
